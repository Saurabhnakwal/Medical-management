﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form7
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Button2 = New Button()
        Button1 = New Button()
        TxtBox8 = New TextBox()
        TxtBox7 = New TextBox()
        TxtBox6 = New TextBox()
        TxtBox5 = New TextBox()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        TxtBox4 = New TextBox()
        Label1 = New Label()
        Label6 = New Label()
        TxtBox1 = New TextBox()
        TxtBox2 = New TextBox()
        Label7 = New Label()
        Label8 = New Label()
        TxtBox3 = New TextBox()
        Label9 = New Label()
        TxtBox9 = New TextBox()
        Label10 = New Label()
        Textid3 = New TextBox()
        Button3 = New Button()
        DataGridView1 = New DataGridView()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.Location = New Point(63, 850)
        Button2.Name = "Button2"
        Button2.Size = New Size(149, 50)
        Button2.TabIndex = 52
        Button2.Text = "Cancel"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.Location = New Point(1543, 780)
        Button1.Name = "Button1"
        Button1.Size = New Size(149, 50)
        Button1.TabIndex = 51
        Button1.Text = "Next"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' TxtBox8
        ' 
        TxtBox8.Location = New Point(476, 583)
        TxtBox8.Multiline = True
        TxtBox8.Name = "TxtBox8"
        TxtBox8.Size = New Size(422, 50)
        TxtBox8.TabIndex = 50
        ' 
        ' TxtBox7
        ' 
        TxtBox7.Location = New Point(476, 508)
        TxtBox7.Multiline = True
        TxtBox7.Name = "TxtBox7"
        TxtBox7.Size = New Size(422, 50)
        TxtBox7.TabIndex = 49
        ' 
        ' TxtBox6
        ' 
        TxtBox6.Location = New Point(476, 431)
        TxtBox6.Multiline = True
        TxtBox6.Name = "TxtBox6"
        TxtBox6.Size = New Size(422, 50)
        TxtBox6.TabIndex = 48
        ' 
        ' TxtBox5
        ' 
        TxtBox5.Location = New Point(476, 356)
        TxtBox5.Multiline = True
        TxtBox5.Name = "TxtBox5"
        TxtBox5.Size = New Size(422, 50)
        TxtBox5.TabIndex = 47
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.Location = New Point(157, 590)
        Label5.Name = "Label5"
        Label5.Size = New Size(82, 22)
        Label5.TabIndex = 46
        Label5.Text = "Bill Date"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.Location = New Point(157, 511)
        Label4.Name = "Label4"
        Label4.Size = New Size(188, 22)
        Label4.TabIndex = 45
        Label4.Text = "Medicine Expiry Date"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(157, 443)
        Label3.Name = "Label3"
        Label3.Size = New Size(161, 22)
        Label3.TabIndex = 44
        Label3.Text = "Medicine Quantity"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(157, 373)
        Label2.Name = "Label2"
        Label2.Size = New Size(138, 22)
        Label2.TabIndex = 43
        Label2.Text = "Medicine Name"
        ' 
        ' TxtBox4
        ' 
        TxtBox4.Location = New Point(476, 280)
        TxtBox4.Multiline = True
        TxtBox4.Name = "TxtBox4"
        TxtBox4.Size = New Size(422, 50)
        TxtBox4.TabIndex = 42
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(157, 290)
        Label1.Name = "Label1"
        Label1.Size = New Size(107, 22)
        Label1.TabIndex = 41
        Label1.Text = "Medicine Id"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.Transparent
        Label6.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.Location = New Point(157, 74)
        Label6.Name = "Label6"
        Label6.Size = New Size(94, 22)
        Label6.TabIndex = 53
        Label6.Text = "Receipt Id"
        ' 
        ' TxtBox1
        ' 
        TxtBox1.Location = New Point(476, 60)
        TxtBox1.Multiline = True
        TxtBox1.Name = "TxtBox1"
        TxtBox1.Size = New Size(422, 50)
        TxtBox1.TabIndex = 54
        ' 
        ' TxtBox2
        ' 
        TxtBox2.Location = New Point(475, 128)
        TxtBox2.Multiline = True
        TxtBox2.Name = "TxtBox2"
        TxtBox2.Size = New Size(422, 50)
        TxtBox2.TabIndex = 55
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.BackColor = Color.Transparent
        Label7.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(157, 149)
        Label7.Name = "Label7"
        Label7.Size = New Size(143, 22)
        Label7.TabIndex = 56
        Label7.Text = "Customer Name"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.BackColor = Color.Transparent
        Label8.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label8.Location = New Point(157, 207)
        Label8.Name = "Label8"
        Label8.Size = New Size(166, 22)
        Label8.TabIndex = 57
        Label8.Text = "Customer Phoneno"
        ' 
        ' TxtBox3
        ' 
        TxtBox3.Location = New Point(476, 207)
        TxtBox3.Multiline = True
        TxtBox3.Name = "TxtBox3"
        TxtBox3.Size = New Size(422, 50)
        TxtBox3.TabIndex = 58
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.BackColor = Color.Transparent
        Label9.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label9.Location = New Point(157, 659)
        Label9.Name = "Label9"
        Label9.Size = New Size(125, 22)
        Label9.TabIndex = 59
        Label9.Text = "Total Amount "
        ' 
        ' TxtBox9
        ' 
        TxtBox9.Location = New Point(476, 654)
        TxtBox9.Multiline = True
        TxtBox9.Name = "TxtBox9"
        TxtBox9.Size = New Size(422, 50)
        TxtBox9.TabIndex = 60
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.BackColor = Color.Transparent
        Label10.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label10.Location = New Point(1145, 78)
        Label10.Name = "Label10"
        Label10.Size = New Size(94, 22)
        Label10.TabIndex = 64
        Label10.Text = "Receipt Id"
        ' 
        ' Textid3
        ' 
        Textid3.Location = New Point(1411, 70)
        Textid3.Multiline = True
        Textid3.Name = "Textid3"
        Textid3.Size = New Size(359, 37)
        Textid3.TabIndex = 63
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.Cyan
        Button3.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.Location = New Point(1311, 668)
        Button3.Name = "Button3"
        Button3.Size = New Size(201, 61)
        Button3.TabIndex = 62
        Button3.Text = "showrecord"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' DataGridView1
        ' 
        DataGridView1.BackgroundColor = Color.Turquoise
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(944, 128)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowTemplate.Height = 25
        DataGridView1.Size = New Size(876, 491)
        DataGridView1.TabIndex = 61
        ' 
        ' Form7
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.blue_medical_background_1_1024x318
        ClientSize = New Size(1850, 934)
        Controls.Add(Label10)
        Controls.Add(Textid3)
        Controls.Add(Button3)
        Controls.Add(DataGridView1)
        Controls.Add(TxtBox9)
        Controls.Add(Label9)
        Controls.Add(TxtBox3)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(TxtBox2)
        Controls.Add(TxtBox1)
        Controls.Add(Label6)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(TxtBox8)
        Controls.Add(TxtBox7)
        Controls.Add(TxtBox6)
        Controls.Add(TxtBox5)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(TxtBox4)
        Controls.Add(Label1)
        Name = "Form7"
        Text = "Bill Generate"
        WindowState = FormWindowState.Maximized
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents TxtBox8 As TextBox
    Friend WithEvents TxtBox7 As TextBox
    Friend WithEvents TxtBox6 As TextBox
    Friend WithEvents TxtBox5 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtBox4 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TxtBox1 As TextBox
    Friend WithEvents TxtBox2 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents TxtBox3 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TxtBox9 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Textid3 As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents DataGridView1 As DataGridView
End Class
