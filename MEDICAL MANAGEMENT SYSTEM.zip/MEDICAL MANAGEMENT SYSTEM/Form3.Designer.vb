﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        TextBox1 = New TextBox()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        TextBox2 = New TextBox()
        TextBox3 = New TextBox()
        TextBox4 = New TextBox()
        TextBox5 = New TextBox()
        TextBox6 = New TextBox()
        Button1 = New Button()
        DataGridView1 = New DataGridView()
        Button3 = New Button()
        Textid = New TextBox()
        Label7 = New Label()
        Button2 = New Button()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(193, 97)
        Label1.Name = "Label1"
        Label1.Size = New Size(117, 22)
        Label1.TabIndex = 0
        Label1.Text = "Employee Id "
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(450, 97)
        TextBox1.Multiline = True
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(359, 37)
        TextBox1.TabIndex = 1
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(193, 180)
        Label2.Name = "Label2"
        Label2.Size = New Size(143, 22)
        Label2.TabIndex = 2
        Label2.Text = "Employee Name"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(193, 261)
        Label3.Name = "Label3"
        Label3.Size = New Size(71, 22)
        Label3.TabIndex = 3
        Label3.Text = "Gender"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.Location = New Point(193, 358)
        Label4.Name = "Label4"
        Label4.Size = New Size(146, 22)
        Label4.TabIndex = 4
        Label4.Text = "Contact Number"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.Location = New Point(193, 427)
        Label5.Name = "Label5"
        Label5.Size = New Size(76, 22)
        Label5.TabIndex = 5
        Label5.Text = "Address"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.Transparent
        Label6.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.Location = New Point(193, 509)
        Label6.Name = "Label6"
        Label6.Size = New Size(60, 22)
        Label6.TabIndex = 6
        Label6.Text = "Gmail"
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(450, 180)
        TextBox2.Multiline = True
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(359, 37)
        TextBox2.TabIndex = 7
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(450, 261)
        TextBox3.Multiline = True
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(359, 37)
        TextBox3.TabIndex = 8
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(450, 343)
        TextBox4.Multiline = True
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(359, 37)
        TextBox4.TabIndex = 9
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(450, 509)
        TextBox5.Multiline = True
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(359, 37)
        TextBox5.TabIndex = 10
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(450, 427)
        TextBox6.Multiline = True
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(359, 37)
        TextBox6.TabIndex = 10
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.Location = New Point(1590, 768)
        Button1.Name = "Button1"
        Button1.Size = New Size(149, 37)
        Button1.TabIndex = 11
        Button1.Text = "Next"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' DataGridView1
        ' 
        DataGridView1.BackgroundColor = Color.Turquoise
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(990, 124)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowTemplate.Height = 25
        DataGridView1.Size = New Size(791, 491)
        DataGridView1.TabIndex = 13
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.Cyan
        Button3.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.Location = New Point(1314, 650)
        Button3.Name = "Button3"
        Button3.Size = New Size(201, 61)
        Button3.TabIndex = 14
        Button3.Text = "showrecord"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Textid
        ' 
        Textid.Location = New Point(1414, 52)
        Textid.Multiline = True
        Textid.Name = "Textid"
        Textid.Size = New Size(359, 37)
        Textid.TabIndex = 15
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.BackColor = Color.Transparent
        Label7.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(1148, 60)
        Label7.Name = "Label7"
        Label7.Size = New Size(163, 22)
        Label7.TabIndex = 16
        Label7.Text = "Enter Employee Id"
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.Location = New Point(193, 765)
        Button2.Name = "Button2"
        Button2.Size = New Size(149, 37)
        Button2.TabIndex = 17
        Button2.Text = "cancel"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Form3
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.blue_medical_background_1_1024x318
        ClientSize = New Size(1793, 890)
        Controls.Add(Button2)
        Controls.Add(Label7)
        Controls.Add(Textid)
        Controls.Add(Button3)
        Controls.Add(DataGridView1)
        Controls.Add(Button1)
        Controls.Add(TextBox6)
        Controls.Add(TextBox5)
        Controls.Add(TextBox4)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(TextBox1)
        Controls.Add(Label1)
        Name = "Form3"
        Text = "Employee Information"
        WindowState = FormWindowState.Maximized
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Button3 As Button
    Friend WithEvents Textid As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Button2 As Button
End Class
