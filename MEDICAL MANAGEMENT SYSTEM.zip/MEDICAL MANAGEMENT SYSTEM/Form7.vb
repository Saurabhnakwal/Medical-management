﻿Imports System.Data.OleDb

Public Class Form7
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim connectionstring As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\asus\Documents\medical_management.accdb"
        Dim connection As New OleDbConnection(connectionstring)
        connection.Open()
        Dim insert As String = "insert into Bill_generate(Receipt_no,Customer_name,Customer_phoneno,Medicine_id,Medicine_name,Medicine_quantity,Medicine_expiry_date,Bill_date,Total_amount) values(@Receipt_no,@Customer_name,@Customer_phoneno,@Medicine_id,@Medicine_name,@Medicine_quantity,@Medicine_expiry_date,@Bill_date,@Total_amount)"
        Dim insertcommand As New OleDbCommand(insert, connection)
        insertcommand.Parameters.AddWithValue("Receipt_no", TxtBox1.Text)
        insertcommand.Parameters.AddWithValue("Customer_name", TxtBox2.Text)
        insertcommand.Parameters.AddWithValue("Customer_phoneno", TxtBox3.Text)
        insertcommand.Parameters.AddWithValue("Medicine_id", TxtBox4.Text)
        insertcommand.Parameters.AddWithValue("Medicine_name", TxtBox5.Text)
        insertcommand.Parameters.AddWithValue("Medicine_quantity", TxtBox6.Text)
        insertcommand.Parameters.AddWithValue("Medicine_expiry_date", TxtBox7.Text)
        insertcommand.Parameters.AddWithValue("Bill_date", TxtBox8.Text)
        insertcommand.Parameters.AddWithValue("Total_amount", TxtBox9.Text)
        insertcommand.ExecuteNonQuery()
        connection.Close()
        MsgBox("data added successfully")
    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TxtBox2.TextChanged

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TxtBox4.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form2.Show()
        Me.Hide()

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub

    Private Sub Textid_TextChanged(sender As Object, e As EventArgs) Handles Textid3.TextChanged
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\asus\Documents\medical_management.accdb")
        If (Textid3.Text IsNot "") Then
            Dim cmd As New OleDbCommand("select * from Bill_generate where Receipt_no=@Receipt_no", conn)
            cmd.Parameters.AddWithValue("@Receipt_no", Textid3.Text)
            Dim adapter As New OleDbDataAdapter(cmd)
            Dim table As New DataTable()
            adapter.Fill(table)
            DataGridView1.DataSource = table
            DataGridView1.Visible = True
        Else
            Dim cmd1 As New OleDbCommand("select * from Bill_generate", conn)
            Dim adapter1 As New OleDbDataAdapter(cmd1)
            Dim table1 As New DataTable()
            adapter1.Fill(table1)
            DataGridView1.DataSource = table1
            DataGridView1.Visible = True

        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
    End Sub
End Class