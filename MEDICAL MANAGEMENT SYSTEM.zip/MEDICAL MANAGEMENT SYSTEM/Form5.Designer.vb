﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Button2 = New Button()
        Button1 = New Button()
        TextBox6 = New TextBox()
        TextBox4 = New TextBox()
        TextBox3 = New TextBox()
        TextBox2 = New TextBox()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        TextBox1 = New TextBox()
        Label1 = New Label()
        txtid3 = New Label()
        Textid3 = New TextBox()
        Button3 = New Button()
        DataGridView1 = New DataGridView()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.Location = New Point(62, 774)
        Button2.Name = "Button2"
        Button2.Size = New Size(149, 37)
        Button2.TabIndex = 40
        Button2.Text = "Cancel"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.Location = New Point(1597, 774)
        Button1.Name = "Button1"
        Button1.Size = New Size(149, 37)
        Button1.TabIndex = 39
        Button1.Text = "Next"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(440, 446)
        TextBox6.Multiline = True
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(343, 37)
        TextBox6.TabIndex = 37
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(440, 375)
        TextBox4.Multiline = True
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(343, 37)
        TextBox4.TabIndex = 36
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(440, 302)
        TextBox3.Multiline = True
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(343, 37)
        TextBox3.TabIndex = 35
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(440, 233)
        TextBox2.Multiline = True
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(343, 37)
        TextBox2.TabIndex = 34
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.Location = New Point(198, 444)
        Label5.Name = "Label5"
        Label5.Size = New Size(133, 22)
        Label5.TabIndex = 32
        Label5.Text = "Medicine Price"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.Location = New Point(198, 373)
        Label4.Name = "Label4"
        Label4.Size = New Size(188, 22)
        Label4.TabIndex = 31
        Label4.Text = "Medicine Expiry Date"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(198, 300)
        Label3.Name = "Label3"
        Label3.Size = New Size(161, 22)
        Label3.TabIndex = 30
        Label3.Text = "Medicine Quantity"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(198, 231)
        Label2.Name = "Label2"
        Label2.Size = New Size(138, 22)
        Label2.TabIndex = 29
        Label2.Text = "Medicine Name"
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(440, 154)
        TextBox1.Multiline = True
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(343, 37)
        TextBox1.TabIndex = 28
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(198, 152)
        Label1.Name = "Label1"
        Label1.Size = New Size(107, 22)
        Label1.TabIndex = 27
        Label1.Text = "Medicine Id"
        ' 
        ' txtid3
        ' 
        txtid3.AutoSize = True
        txtid3.BackColor = Color.Transparent
        txtid3.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        txtid3.Location = New Point(1072, 55)
        txtid3.Name = "txtid3"
        txtid3.Size = New Size(158, 22)
        txtid3.TabIndex = 46
        txtid3.Text = "Enter Medicine Id"
        ' 
        ' Textid3
        ' 
        Textid3.Location = New Point(1327, 55)
        Textid3.Multiline = True
        Textid3.Name = "Textid3"
        Textid3.Size = New Size(359, 37)
        Textid3.TabIndex = 45
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.Cyan
        Button3.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.Location = New Point(1262, 649)
        Button3.Name = "Button3"
        Button3.Size = New Size(201, 61)
        Button3.TabIndex = 44
        Button3.Text = "showrecord"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' DataGridView1
        ' 
        DataGridView1.BackgroundColor = Color.Turquoise
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(961, 116)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowTemplate.Height = 25
        DataGridView1.Size = New Size(791, 491)
        DataGridView1.TabIndex = 43
        ' 
        ' Form5
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.blue_medical_background_1_1024x318
        ClientSize = New Size(1856, 840)
        Controls.Add(txtid3)
        Controls.Add(Textid3)
        Controls.Add(Button3)
        Controls.Add(DataGridView1)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(TextBox6)
        Controls.Add(TextBox4)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(TextBox1)
        Controls.Add(Label1)
        Name = "Form5"
        Text = "Purchase Form"
        WindowState = FormWindowState.Maximized
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtid3 As Label
    Friend WithEvents Textid3 As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents DataGridView1 As DataGridView
End Class
