﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Button2 = New Button()
        Button1 = New Button()
        TextBox6 = New TextBox()
        TextBox5 = New TextBox()
        TextBox4 = New TextBox()
        TextBox3 = New TextBox()
        TextBox2 = New TextBox()
        Label6 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        TextBox1 = New TextBox()
        Label1 = New Label()
        TextBox7 = New TextBox()
        Label7 = New Label()
        TextBox8 = New TextBox()
        Label8 = New Label()
        TextBox9 = New TextBox()
        Label9 = New Label()
        DataGridView1 = New DataGridView()
        Button3 = New Button()
        txtid2 = New Label()
        Textid = New TextBox()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.Location = New Point(103, 781)
        Button2.Name = "Button2"
        Button2.Size = New Size(149, 37)
        Button2.TabIndex = 26
        Button2.Text = "Cancel"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.Location = New Point(1566, 781)
        Button1.Name = "Button1"
        Button1.Size = New Size(149, 37)
        Button1.TabIndex = 25
        Button1.Text = "Next"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(451, 316)
        TextBox6.Multiline = True
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(387, 37)
        TextBox6.TabIndex = 23
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(451, 240)
        TextBox5.Multiline = True
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(387, 37)
        TextBox5.TabIndex = 24
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(451, 170)
        TextBox4.Multiline = True
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(387, 37)
        TextBox4.TabIndex = 22
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(451, 97)
        TextBox3.Multiline = True
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(387, 37)
        TextBox3.TabIndex = 21
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(645, -186)
        TextBox2.Multiline = True
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(256, 37)
        TextBox2.TabIndex = 20
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.Transparent
        Label6.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.Location = New Point(178, 489)
        Label6.Name = "Label6"
        Label6.Size = New Size(133, 22)
        Label6.TabIndex = 19
        Label6.Text = "Medicine Price"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.Location = New Point(178, 410)
        Label5.Name = "Label5"
        Label5.Size = New Size(179, 22)
        Label5.TabIndex = 18
        Label5.Text = "Medicine Compound"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.Location = New Point(179, 331)
        Label4.Name = "Label4"
        Label4.Size = New Size(188, 22)
        Label4.TabIndex = 17
        Label4.Text = "Medicine Expiry Date"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(178, 244)
        Label3.Name = "Label3"
        Label3.Size = New Size(161, 22)
        Label3.TabIndex = 16
        Label3.Text = "Medicine Quantity"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(403, -186)
        Label2.Name = "Label2"
        Label2.Size = New Size(138, 22)
        Label2.TabIndex = 15
        Label2.Text = "Medicine Name"
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(645, -259)
        TextBox1.Multiline = True
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(256, 37)
        TextBox1.TabIndex = 14
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(403, -259)
        Label1.Name = "Label1"
        Label1.Size = New Size(107, 22)
        Label1.TabIndex = 13
        Label1.Text = "Medicine Id"
        ' 
        ' TextBox7
        ' 
        TextBox7.Location = New Point(451, 395)
        TextBox7.Multiline = True
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(387, 37)
        TextBox7.TabIndex = 27
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.BackColor = Color.Transparent
        Label7.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(178, 552)
        Label7.Name = "Label7"
        Label7.Size = New Size(125, 22)
        Label7.TabIndex = 28
        Label7.Text = "Batch number"
        ' 
        ' TextBox8
        ' 
        TextBox8.Location = New Point(451, 472)
        TextBox8.Multiline = True
        TextBox8.Name = "TextBox8"
        TextBox8.Size = New Size(387, 37)
        TextBox8.TabIndex = 38
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.BackColor = Color.Transparent
        Label8.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label8.Location = New Point(179, 185)
        Label8.Name = "Label8"
        Label8.Size = New Size(138, 22)
        Label8.TabIndex = 37
        Label8.Text = "Medicine Name"
        ' 
        ' TextBox9
        ' 
        TextBox9.Location = New Point(451, 540)
        TextBox9.Multiline = True
        TextBox9.Name = "TextBox9"
        TextBox9.Size = New Size(387, 37)
        TextBox9.TabIndex = 36
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.BackColor = Color.Transparent
        Label9.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label9.Location = New Point(179, 106)
        Label9.Name = "Label9"
        Label9.Size = New Size(107, 22)
        Label9.TabIndex = 35
        Label9.Text = "Medicine Id"
        ' 
        ' DataGridView1
        ' 
        DataGridView1.BackgroundColor = Color.Turquoise
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(990, 97)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowTemplate.Height = 25
        DataGridView1.Size = New Size(791, 491)
        DataGridView1.TabIndex = 39
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.Cyan
        Button3.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.Location = New Point(1291, 630)
        Button3.Name = "Button3"
        Button3.Size = New Size(201, 61)
        Button3.TabIndex = 40
        Button3.Text = "showrecord"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' txtid2
        ' 
        txtid2.AutoSize = True
        txtid2.BackColor = Color.Transparent
        txtid2.Font = New Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        txtid2.Location = New Point(1101, 36)
        txtid2.Name = "txtid2"
        txtid2.Size = New Size(158, 22)
        txtid2.TabIndex = 42
        txtid2.Text = "Enter Medicine Id"
        ' 
        ' Textid
        ' 
        Textid.Location = New Point(1356, 36)
        Textid.Multiline = True
        Textid.Name = "Textid"
        Textid.Size = New Size(359, 37)
        Textid.TabIndex = 41
        ' 
        ' Form4
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.blue_medical_background_1_1024x318
        ClientSize = New Size(1849, 914)
        Controls.Add(txtid2)
        Controls.Add(Textid)
        Controls.Add(Button3)
        Controls.Add(DataGridView1)
        Controls.Add(TextBox8)
        Controls.Add(Label8)
        Controls.Add(TextBox9)
        Controls.Add(Label9)
        Controls.Add(Label7)
        Controls.Add(TextBox7)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(TextBox6)
        Controls.Add(TextBox5)
        Controls.Add(TextBox4)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(TextBox1)
        Controls.Add(Label1)
        Name = "Form4"
        Text = "Medicine Information"
        WindowState = FormWindowState.Maximized
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Button3 As Button
    Friend WithEvents txtid2 As Label
    Friend WithEvents Textid As TextBox
End Class
