﻿Imports System.Data.OleDb

Public Class Form3

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim connectionstring As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\asus\Documents\medical_management.accdb"
        Dim connection As New OleDbConnection(connectionstring)
        connection.Open()
        Dim insert As String = "insert into employee(Employee_id,Employee_name,Gender,Contact_number,Address,Gmail) values(@Employee_id,@Employee_name,@Gender,@Contact_number,@Address,@Gmail) "
        Dim insertcommand As New OleDbCommand(insert, connection)
        insertcommand.Parameters.AddWithValue("Employee_id", Integer.Parse(TextBox1.Text))
        insertcommand.Parameters.AddWithValue("Employee_name", TextBox2.Text)
        insertcommand.Parameters.AddWithValue("Gender", TextBox3.Text)
        insertcommand.Parameters.AddWithValue("contact_number", Integer.Parse(TextBox4.Text))
        insertcommand.Parameters.AddWithValue("Address", TextBox5.Text)
        insertcommand.Parameters.AddWithValue("Gmail", TextBox6.Text)
        insertcommand.ExecuteNonQuery()
        connection.Close()
        MsgBox("data added successfully")

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\asus\Documents\medical_management.accdb")
        If (Textid.Text IsNot "") Then
            Dim cmd As New OleDbCommand("select *from employee where Employee_id = @Employee_id", conn)
            cmd.Parameters.AddWithValue("@Employee_id", Textid.Text)
            Dim adapter As New OleDbDataAdapter(cmd)
            Dim table As New DataTable()
            adapter.Fill(table)
            DataGridView1.DataSource = table
            DataGridView1.Visible = True
        Else
            Dim cmd1 As New OleDbCommand("select * from employee", conn)
            Dim adapter1 As New OleDbDataAdapter(cmd1)
            Dim table1 As New DataTable()
            adapter1.Fill(table1)
            DataGridView1.DataSource = table1

            DataGridView1.Visible = True

        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form2.Show()
    End Sub
End Class