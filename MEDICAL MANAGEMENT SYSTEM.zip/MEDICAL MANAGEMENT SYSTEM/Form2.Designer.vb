﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        DateTimePicker1 = New DateTimePicker()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Button5 = New Button()
        Label1 = New Label()
        SuspendLayout()
        ' 
        ' DateTimePicker1
        ' 
        DateTimePicker1.Location = New Point(1615, 2)
        DateTimePicker1.Name = "DateTimePicker1"
        DateTimePicker1.Size = New Size(190, 23)
        DateTimePicker1.TabIndex = 0
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        Button1.BackgroundImageLayout = ImageLayout.Stretch
        Button1.Font = New Font("Rockwell", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.ForeColor = SystemColors.ActiveCaptionText
        Button1.Location = New Point(1442, 269)
        Button1.Name = "Button1"
        Button1.Size = New Size(366, 53)
        Button1.TabIndex = 1
        Button1.Text = "Employee Information"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        Button2.BackgroundImageLayout = ImageLayout.Stretch
        Button2.Font = New Font("Rockwell", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = SystemColors.ActiveCaptionText
        Button2.Location = New Point(1442, 359)
        Button2.Name = "Button2"
        Button2.Size = New Size(366, 53)
        Button2.TabIndex = 2
        Button2.Text = "Medicine Information"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        Button3.BackgroundImageLayout = ImageLayout.Stretch
        Button3.Font = New Font("Rockwell", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.ForeColor = SystemColors.ActiveCaptionText
        Button3.Location = New Point(1442, 445)
        Button3.Name = "Button3"
        Button3.Size = New Size(366, 53)
        Button3.TabIndex = 3
        Button3.Text = "Purchase Record"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        Button5.BackgroundImageLayout = ImageLayout.Stretch
        Button5.Font = New Font("Rockwell", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button5.ForeColor = SystemColors.ActiveCaptionText
        Button5.Location = New Point(1442, 532)
        Button5.Name = "Button5"
        Button5.Size = New Size(366, 47)
        Button5.TabIndex = 5
        Button5.Text = "Generate Bill"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("MV Boli", 48F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(322, 817)
        Label1.Name = "Label1"
        Label1.Size = New Size(1311, 85)
        Label1.TabIndex = 6
        Label1.Text = "Welcome to Medical Management System"
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Gray
        BackgroundImage = My.Resources.Resources.medical_background_with_loop_n26ve__yg_thumbnail_1080_05
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(1805, 923)
        Controls.Add(Label1)
        Controls.Add(Button5)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(DateTimePicker1)
        FormBorderStyle = FormBorderStyle.FixedDialog
        Name = "Form2"
        Text = "Welcome Page"
        WindowState = FormWindowState.Maximized
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Label1 As Label
End Class
