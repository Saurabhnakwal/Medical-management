﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub Login_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)

    End Sub

    Private Sub Login_Click_1(sender As Object, e As EventArgs) Handles Login.Click
        Dim pass As Integer
        pass = Integer.Parse(TextBox2.Text)
        If (pass = 916675) Then
            Form2.Show()
        Else
            MsgBox("wrong password")

        End If


    End Sub

    Private Sub Form1_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
