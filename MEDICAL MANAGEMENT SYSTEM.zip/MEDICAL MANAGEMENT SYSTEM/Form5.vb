﻿Imports System.Data.OleDb
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form5
    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim connectionstring As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\asus\Documents\medical_management.accdb"
        Dim connection As New OleDbConnection(connectionstring)
        connection.Open()
        Dim insert As String = "insert into purchase(Medicine_id,Medicine_name,Medicine_quantity,Medicine_Expiry_Date,Medicine_price) values(@medicine_id,@medicine_name,@Medicine_quantity,@Medicine_Expiry_Date,@Medicine_price) "
        Dim insertcommand As New OleDbCommand(insert, connection)
        insertcommand.Parameters.AddWithValue("Medicine_id", TextBox1.Text)
        insertcommand.Parameters.AddWithValue("Medicine_name", TextBox2.Text)
        insertcommand.Parameters.AddWithValue("Medicine_quantity", TextBox3.Text)
        insertcommand.Parameters.AddWithValue("Medicine_Expiry_Date", TextBox4.Text)
        insertcommand.Parameters.AddWithValue("Medicine_price", TextBox6.Text)
        insertcommand.ExecuteNonQuery()
        connection.Close()
        MsgBox("data added successfully")


    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\asus\Documents\medical_management.accdb")
        If (Textid3.Text IsNot "") Then
            Dim cmd As New OleDbCommand("select *from purchase where Medicine_id = @Medicine_id", conn)
            cmd.Parameters.AddWithValue("@Medicine_id", Textid3.Text)
            Dim adapter As New OleDbDataAdapter(cmd)
            Dim table As New DataTable()
            adapter.Fill(table)
            DataGridView1.DataSource = table
            DataGridView1.Visible = True
        Else
            Dim cmd1 As New OleDbCommand("select * from purchase", conn)
            Dim adapter1 As New OleDbDataAdapter(cmd1)
            Dim table1 As New DataTable()
            adapter1.Fill(table1)
            DataGridView1.DataSource = table1

            DataGridView1.Visible = True

        End If
    End Sub
End Class