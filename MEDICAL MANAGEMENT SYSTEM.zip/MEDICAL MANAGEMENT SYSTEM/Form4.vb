﻿Imports System.Buffers
Imports System.Data.OleDb

Public Class Form4
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim connectionstring As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\asus\Documents\medical_management.accdb"
        Dim connection As New OleDbConnection(connectionstring)
        connection.Open()
        Dim insert As String = "insert into medical_information(Medicine_id,Medicine_name,Medicine_quantity,Medicine_Expiry_Date,Medicine_compount,Medicine_price,Batch_no) values(@medicine_id,@medicine_name,@Medicine_quantity,@Medicine_Expiry_Date,@Medicine_compount,@Medicine_price,@Batch_no) "
        Dim insertcommand As New OleDbCommand(insert, connection)
        insertcommand.Parameters.AddWithValue("Medicine_id", TextBox3.Text)
        insertcommand.Parameters.AddWithValue("Medicine_name", TextBox4.Text)
        insertcommand.Parameters.AddWithValue("Medicine_quantity", TextBox5.Text)
        insertcommand.Parameters.AddWithValue("Medicine_Expiry_Date", TextBox6.Text)
        insertcommand.Parameters.AddWithValue("Medicine_compount", TextBox7.Text)
        insertcommand.Parameters.AddWithValue("Medicine_price", TextBox8.Text)
        insertcommand.Parameters.AddWithValue("Batch_no", TextBox9.Text)
        insertcommand.ExecuteNonQuery()
        connection.Close()
        MsgBox("data added successfully")

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\asus\Documents\medical_management.accdb")
        If (Textid.Text IsNot "") Then
            Dim cmd As New OleDbCommand("select *from medical_information where Medicine_id = @Medicine_id", conn)
            cmd.Parameters.AddWithValue("@Medicine_id", Textid.Text)
            Dim adapter As New OleDbDataAdapter(cmd)
            Dim table As New DataTable()
            adapter.Fill(table)
            DataGridView1.DataSource = table
            DataGridView1.Visible = True
        Else
            Dim cmd1 As New OleDbCommand("select * from medical_information", conn)
            Dim adapter1 As New OleDbDataAdapter(cmd1)
            Dim table1 As New DataTable()
            adapter1.Fill(table1)
            DataGridView1.DataSource = table1
            DataGridView1.Visible = True

        End If
    End Sub

    Private Sub Textid_TextChanged(sender As Object, e As EventArgs) Handles Textid.TextChanged

    End Sub

    Private Sub txtid2_Click(sender As Object, e As EventArgs) Handles txtid2.Click
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
    End Sub
End Class